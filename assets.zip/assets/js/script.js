document.addEventListener("DOMContentLoaded", function() {
    // Exibir ícone de recarregamento
    const loadingIcon = document.getElementById("loading-icon");
    loadingIcon.style.display = "block";

    // Ocultar ícone de recarregamento após 2 segundos
    setTimeout(function() {
        loadingIcon.style.display = "none";
    }, 2000);

    // Adicionar evento de clique a todos os botões
    const buttons = document.querySelectorAll("a.nav-button, a.social-button, a.contact-option");
    buttons.forEach(button => {
        button.addEventListener("click", function() {
            this.classList.add("button-clicked");
            setTimeout(() => {
                this.classList.remove("button-clicked");
            }, 300);
        });
    });
});